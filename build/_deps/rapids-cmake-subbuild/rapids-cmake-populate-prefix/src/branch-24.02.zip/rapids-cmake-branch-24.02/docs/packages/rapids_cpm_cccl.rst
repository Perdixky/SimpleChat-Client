.. cmake-module:: ../../rapids-cmake/cpm/cccl.cmake
