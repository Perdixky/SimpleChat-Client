.. cmake-module:: ../../rapids-cmake/cython/add_rpath_entries.cmake
