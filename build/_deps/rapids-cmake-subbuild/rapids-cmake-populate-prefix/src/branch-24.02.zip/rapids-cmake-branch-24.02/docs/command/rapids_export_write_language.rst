.. cmake-module:: ../../rapids-cmake/export/write_language.cmake
