.. cmake-module:: ../../rapids-cmake/export/find_package_root.cmake
