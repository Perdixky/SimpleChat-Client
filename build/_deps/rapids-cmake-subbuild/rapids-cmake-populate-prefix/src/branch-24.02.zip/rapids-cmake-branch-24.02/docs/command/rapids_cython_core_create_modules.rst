.. cmake-module:: ../../rapids-cmake/cython-core/create_modules.cmake
